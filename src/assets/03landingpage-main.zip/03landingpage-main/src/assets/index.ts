import smiling from "./bg/img-11.png";
import navlogo from "./branding/topupaccess1.png";
import smilingtwo from "./bg/smiling2.png";
import supportIcon from "./utility/customer-service-icon.png";
import swiftIcon from "./utility/flash-icon.png";
import specialIcon from "./utility/special-discount.png";
import airtime from "./bg/contact-list.png";
import data from "./bg/data.jpg";
import cable from "./bg/cable.jpg";
import bulb from "./bg/bulb.png";
import sms from "./bg/sms.png";
import barcode from "./bg/barcode.png";
export {
    smiling,
    navlogo,
    smilingtwo,
    supportIcon,
    swiftIcon,
    specialIcon,
    airtime,
    data,
    cable,
    bulb,
    sms,
    barcode
}