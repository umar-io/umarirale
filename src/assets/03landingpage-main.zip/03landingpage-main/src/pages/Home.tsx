import { Hero , SiteFeature , Services} from "..";
const Home = () => {
  return (
    <>
      <Hero />
      <SiteFeature />
      <Services />
    </>
  );
};
export default Home;
